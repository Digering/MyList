public class Stec {

    public static void main(String[] args) {

        MyStec stec = new MyStec(3);

        stec.add(8);
        stec.add(18);
        stec.add(4);
        stec.add(9);
        stec.add(6);

        stec.print();
        System.out.println("");

        int x = stec.dost();
        System.out.println(x);
        System.out.println("");

        stec.print();
    }
}

public class MySortingMass {

    int[] items;

    public MySortingMass(int[] items){
        this.items = items;
    }

    private void Swap(int[] items, int left, int right){
        if (left != right){
            int temp = items[left];
            items[left] = items[right];
            items[right] = temp;
        }
    }
    public void Bubble_sorting(){

        boolean  swapped;
        do
        {
            swapped = false;
            for (int i = 1; i < items.length; i++) {
                if (items[i-1]>items[i])
                {
                    Swap(items, i - 1, i);
                    swapped = true;
                }
            }
        } while (swapped);

    }

    public void Sort()
    {
        int RangeEnd = 0;

        while (RangeEnd < items.length)
        {
            int nextIndex = Sorting_by_choice(items, RangeEnd);
            Swap(items, RangeEnd, nextIndex);

            RangeEnd++;
        }
    }

    private int Sorting_by_choice(int[] items, int RangeEnd)
    {
        int current = items[RangeEnd];
        int currentSmall = RangeEnd;

        for (int i = RangeEnd + 1; i < items.length; i++)
        {
            if (current > items[i])
            {
                current = items[i];
                currentSmall = i;
            }
        }

        return currentSmall;
    }

    public void Print(){
        for (int i=0; i<items.length;i++)
            System.out.print(items[i]+" ");
    }

}

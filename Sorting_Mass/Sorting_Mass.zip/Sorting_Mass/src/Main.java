public class Main {
    public static void main(String[] args) {
        int[] mas1 = new int[]{14,7,1,4,2};
        int[] mas2 = new int[]{14,7,1,4,2};
        MySortingMass mas12 = new MySortingMass(mas1);
        MySortingMass mas22 = new MySortingMass(mas2);

        long start = System.nanoTime();

        System.out.println("");
        System.out.println("Сортировка выбором: ");
        mas12.Print();
        System.out.println("");
        mas12.Sort();
        mas12.Print();
        long finish1 = System.nanoTime();
        System.out.println("");
        System.out.println("Время выполнения: "+(finish1-start)/ 1000000);

        System.out.println("");
        System.out.println("Пузырьковая сортировка: ");
        mas22.Print();
        System.out.println("");
        mas22.Bubble_sorting();
        mas22.Print();
        long finish2 = System.nanoTime();
        System.out.println("");
        System.out.println("Время выполнения: "+(finish2-start)/ 1000000);
    }
}
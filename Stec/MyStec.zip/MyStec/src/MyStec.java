public class MyStec {

    public int[] mas;

    public MyStec(){}
    public MyStec(int x){ add(x);}


    public void add(int num){
        int[] mas2;

        if (mas == null){
            mas = new int[1];
            mas[0] = num;
        }else{
            mas2 = new int[mas.length];
            for(int i=0; i<mas.length; i++){
                mas2[i] = mas[i];
            }
            mas = new int[mas.length+1];
            mas[0] = num;
            for(int i=1; i<mas.length; i++){
                mas[i] = mas2[i-1];
            }
        }
    }

    public int dost(){
        int mas3 = mas[0];
        int mas2[] = new int[mas.length-1];
        for (int j = 0; j < mas2.length; j++){
            mas2[j] = mas[j+1];
        }
        mas = mas2;

        return mas3;
    }

    public void print(){
        if(mas != null){
            for(int i=0; i<mas.length; i++){
                System.out.println(mas[i]);
            }
        }else{
            System.out.println("null");
        }
    }

}

public class Main {
    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();

        tree.Add(8);
        tree.Add(5);
        tree.Add(10);

        tree.Print();
        System.out.println(" ");

        if(tree.Count() == 3){
            tree.Add(14);
            tree.Add(9);
            tree.Add(2);
            tree.Add(7);
            tree.Add(6);
        }

        tree.Print();
        System.out.println(" ");

        if(tree.Contains(6)){
            tree.Remove(6);
        }

        tree.Print();
        System.out.println(" ");

        tree.Clear();

        tree.Print();
        System.out.println(" ");


    }
}
public class Main {
    public static void main(String[] args) {
        MyQueue queue = new MyQueue();
        queue.Enqueue(2);
        queue.Enqueue(9);
        queue.Enqueue(12);
        queue.Enqueue(6);

        queue.Print();

        System.out.println("");
        System.out.println(queue.Dequeue());
        System.out.println("");

        queue.Print();
        System.out.println("");

        System.out.println(queue.Count());
    }
}